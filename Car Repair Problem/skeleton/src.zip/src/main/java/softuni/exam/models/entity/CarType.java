package softuni.exam.models.entity;

public enum CarType {
    SUV, coupe, sport
}
